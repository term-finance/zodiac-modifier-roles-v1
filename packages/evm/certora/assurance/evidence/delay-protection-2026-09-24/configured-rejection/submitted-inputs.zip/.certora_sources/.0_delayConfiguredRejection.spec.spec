/* This lemma assumes the postcondition proved by the independent configuration
   transition lemma. It is not evidence for that postcondition by itself. */
methods {
    unresolved external in _._ => DISPATCH [] default ASSERT_FALSE;
    function multisend() external returns (address) envfree;
    function clearanceOf(uint16,address) external returns (RolesHarness.Clearance) envfree;
    function functionScopeConfigForData(uint16,address,bytes) external returns (uint256) envfree;
}
rule configuredSelectorCannotBeForwarded(address to, bytes data, uint16 role, uint256 value, Enum.Operation operation, bool shouldRevert) {
    require to != multisend(), "The approved policy excludes the multisend parser target";
    require clearanceOf(role, to) == RolesHarness.Clearance.Function, "Established by the separate configuration transition lemma";
    require functionScopeConfigForData(role, to, data) == 0, "Established for every non-veto selector by the separate configuration transition lemma";
    storage configured = lastStorage;
    env caller;
    callTargetFunctionWithRole@withrevert(caller, to, data, role);
    assert lastReverted, "cleared selector passed direct forwarding";
    execTransactionWithRole@withrevert(caller, to, value, data, operation, role, shouldRevert) at configured;
    assert lastReverted, "cleared selector passed Safe forwarding";
    execTransactionWithRoleReturnData@withrevert(caller, to, value, data, operation, role, shouldRevert) at configured;
    assert lastReverted, "cleared selector passed return-data forwarding";
}
