/*
 * A target scoped to functions must reject an explicitly cleared selector
 * through every implemented Roles forwarding entrypoint. This is a policy
 * transition theorem for any role, target and payload, not a deployment or
 * Safe/Delay correctness theorem. The special multisend target is excluded
 * because it parses and authorizes inner transactions instead; deployment
 * checks bind multisend separately.
 */
methods {
    function owner() external returns (address) envfree;
    function multisend() external returns (address) envfree;
    function selectorForData(bytes) external returns (bytes4) envfree;
    function clearanceOf(uint16,address) external returns (RolesHarness.Clearance) envfree;
    function functionScopeConfigForData(uint16,address,bytes) external returns (uint256) envfree;
}

rule revokedSelectorCannotBeForwarded(address to, bytes data, uint16 role) {
    env admin;
    require admin.msg.sender == owner();
    require admin.msg.value == 0;
    require to != multisend();
    bytes4 deniedSelector = selectorForData(data);

    scopeTarget(admin, role, to);
    scopeRevokeFunction(admin, role, to, deniedSelector);
    assert clearanceOf(role, to) == RolesHarness.Clearance.Function;
    assert functionScopeConfigForData(role, to, data) == 0;

    storage configured = lastStorage;
    env caller;
    callTargetFunctionWithRole@withrevert(caller, to, data, role);
    assert lastReverted, "cleared selector passed direct forwarding";

    execTransactionWithRole@withrevert(caller, to, 0, data, Enum.Operation.Call, role, false) at configured;
    assert lastReverted, "cleared selector passed Safe forwarding";

    execTransactionWithRoleReturnData@withrevert(caller, to, 0, data, Enum.Operation.Call, role, false) at configured;
    assert lastReverted, "cleared selector passed return-data forwarding";
}
